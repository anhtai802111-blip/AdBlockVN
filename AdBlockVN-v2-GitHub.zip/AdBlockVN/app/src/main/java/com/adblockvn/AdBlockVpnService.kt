package com.adblockvn

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.util.concurrent.atomic.AtomicBoolean

class AdBlockVpnService : VpnService() {
    companion object {
        const val ACTION_STATS = "com.adblockvn.STATS"
        const val PREFS = "adblock"
        const val KEY_BLOCKED = "blocked_count"
        val BLOCKLIST = setOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adservice.google.com",
            "ads.yahoo.com", "advertising.com", "adnxs.com", "adform.net", "taboola.com",
            "outbrain.com", "criteo.com", "scorecardresearch.com", "zedo.com", "rubiconproject.com",
            "pubmatic.com", "openx.net", "smartadserver.com", "2mdn.net", "app-measurement.com",
            "analytics.google.com", "google-analytics.com", "connect.facebook.net", "facebook.net"
        )
    }

    private var tun: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!running.get()) startVpn()
        return START_STICKY
    }

    private fun startVpn() {
        tun = Builder()
            .setSession("AdBlock VN")
            .setMtu(1500)
            .addAddress("10.10.0.2", 32)
            .addRoute("10.10.0.1", 32)
            .addDnsServer("10.10.0.1")
            .establish()
        running.set(tun != null)
        if (running.get()) Thread(::loop, "AdBlockDns").start()
    }

    private fun loop() {
        val fd = tun ?: return
        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val buf = ByteArray(32767)
        while (running.get()) {
            val n = try { input.read(buf) } catch (_: Exception) { break }
            if (n < 28 || (buf[0].toInt() and 0x0f) != 4) continue
            val ihl = (buf[0].toInt() and 0x0f) * 4
            if ((buf[9].toInt() and 255) != 17 || n < ihl + 8) continue
            val dst = ip(buf, 16)
            if (dst != "10.10.0.1") continue
            val sport = u16(buf, ihl)
            val dport = u16(buf, ihl + 2)
            if (dport != 53 || n < ihl + 8 + 12) continue

            val dns = buf.copyOfRange(ihl + 8, n)
            val name = parseName(dns) ?: continue
            val response = if (isBlocked(name)) {
                incrementBlocked()
                blockedResponse(dns)
            } else {
                forwardDns(dns) ?: continue
            }
            output.write(udpIpv4("10.10.0.1", "10.10.0.2", sport, 53, response))
        }
    }

    private fun incrementBlocked() {
        val p = getSharedPreferences(PREFS, MODE_PRIVATE)
        val count = p.getLong(KEY_BLOCKED, 0L) + 1L
        p.edit().putLong(KEY_BLOCKED, count).apply()
        sendBroadcast(Intent(ACTION_STATS).putExtra(KEY_BLOCKED, count))
    }

    private fun isBlocked(name: String): Boolean {
        val x = name.lowercase().trimEnd('.')
        return BLOCKLIST.any { x == it || x.endsWith(".$it") }
    }

    private fun parseName(d: ByteArray): String? {
        if (d.size < 13 || u16(d, 4) < 1) return null
        var p = 12
        val parts = mutableListOf<String>()
        var guard = 0
        while (p < d.size && guard++ < 100) {
            val len = d[p].toInt() and 255
            p++
            if (len == 0) break
            if (len > 63 || p + len > d.size) return null
            parts += String(d, p, len, Charsets.UTF_8)
            p += len
        }
        return parts.takeIf { it.isNotEmpty() }?.joinToString(".")
    }

    private fun blockedResponse(q: ByteArray): ByteArray {
        val end = findQuestionEnd(q)
        val out = q.copyOf(end)
        out[2] = (out[2].toInt() or 0x80).toByte() // QR
        out[3] = (out[3].toInt() or 0x03).toByte() // NXDOMAIN
        out[6] = 0; out[7] = 0; out[8] = 0; out[9] = 0; out[10] = 0; out[11] = 0
        return out
    }

    private fun findQuestionEnd(d: ByteArray): Int {
        var p = 12
        var guard = 0
        while (p < d.size && guard++ < 100) {
            val len = d[p].toInt() and 255
            p++
            if (len == 0) break
            if (len > 63) return minOf(p, d.size)
            p += len
        }
        return minOf(p + 4, d.size)
    }

    private fun forwardDns(d: ByteArray): ByteArray? = try {
        DatagramSocket().use { s ->
            protect(s)
            s.soTimeout = 2500
            s.send(DatagramPacket(d, d.size, InetSocketAddress("1.1.1.1", 53)))
            val b = ByteArray(4096)
            val r = DatagramPacket(b, b.size)
            s.receive(r)
            b.copyOf(r.length)
        }
    } catch (_: Exception) { null }

    private fun udpIpv4(src: String, dst: String, sport: Int, dport: Int, payload: ByteArray): ByteArray {
        val total = 20 + 8 + payload.size
        val b = ByteArray(total)
        b[0] = 0x45
        b[2] = (total ushr 8).toByte(); b[3] = total.toByte()
        b[8] = 64; b[9] = 17
        putIp(b, 12, src); putIp(b, 16, dst)
        put16(b, 20, sport); put16(b, 22, dport); put16(b, 24, 8 + payload.size)
        System.arraycopy(payload, 0, b, 28, payload.size)
        put16(b, 10, checksum(b, 0, 20))
        put16(b, 26, udpChecksum(b))
        return b
    }

    private fun udpChecksum(b: ByteArray): Int {
        var sum = 0L
        fun add(v: Int) { sum += v.toLong(); while (sum > 0xffff) sum = (sum and 0xffff) + 1 }
        for (i in 12 until 20 step 2) add(u16(b, i))
        add(17); add(u16(b, 24))
        for (i in 20 until b.size step 2) add(((b[i].toInt() and 255) shl 8) or (if (i + 1 < b.size) b[i + 1].toInt() and 255 else 0))
        val result = sum.inv().toInt() and 0xffff
        return if (result == 0) 0xffff else result
    }

    private fun checksum(b: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        for (i in offset until offset + length step 2) {
            if (i == 10) continue
            sum += (((b[i].toInt() and 255) shl 8) or (if (i + 1 < offset + length) b[i + 1].toInt() and 255 else 0)).toLong()
            while (sum > 0xffff) sum = (sum and 0xffff) + 1
        }
        return sum.inv().toInt() and 0xffff
    }

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 255) shl 8) or (b[o + 1].toInt() and 255)
    private fun put16(b: ByteArray, o: Int, v: Int) { b[o] = (v ushr 8).toByte(); b[o + 1] = v.toByte() }
    private fun ip(b: ByteArray, o: Int) = "${b[o].toInt() and 255}.${b[o + 1].toInt() and 255}.${b[o + 2].toInt() and 255}.${b[o + 3].toInt() and 255}"
    private fun putIp(b: ByteArray, o: Int, s: String) { s.split('.').forEachIndexed { i, x -> b[o + i] = x.toInt().toByte() } }

    override fun onDestroy() {
        running.set(false)
        try { tun?.close() } catch (_: Exception) { }
        tun = null
        super.onDestroy()
    }

    override fun onRevoke() { stopSelf() }
}
