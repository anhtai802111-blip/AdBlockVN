package com.adblockvn

import android.app.Activity
import android.content.*
import android.graphics.Color
import android.net.VpnService
import android.os.Bundle
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var stats: TextView
    private var running = false

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == AdBlockVpnService.ACTION_STATS) updateStats()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 60, 40, 40)
        }
        val title = TextView(this).apply { text = "AdBlock VN"; textSize = 30f; setTextColor(Color.rgb(25,25,25)) }
        val desc = TextView(this).apply { text = "Chặn quảng cáo & tracker bằng DNS"; textSize = 16f; setPadding(0,12,0,24) }
        status = TextView(this).apply { textSize = 18f; setTextColor(Color.DKGRAY) }
        toggle = Button(this).apply { text = "BẬT CHẶN QUẢNG CÁO"; setOnClickListener { toggleVpn() } }
        stats = TextView(this).apply { textSize = 16f; setPadding(0,20,0,20) }
        val domains = TextView(this).apply {
            textSize = 13f
            text = "DOMAIN ĐANG CHẶN\n\n" + AdBlockVpnService.BLOCKLIST.sorted().joinToString("\n") { "• $it" }
        }
        root.addView(title)
        root.addView(desc)
        root.addView(status)
        root.addView(toggle)
        root.addView(stats)
        val scroll = ScrollView(this).apply { addView(domains, ViewGroup.LayoutParams(-1, -2)) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        updateStats()
        setStatus(false)
    }

    override fun onStart() {
        super.onStart()
        registerReceiver(receiver, IntentFilter(AdBlockVpnService.ACTION_STATS), RECEIVER_NOT_EXPORTED)
    }

    override fun onStop() {
        unregisterReceiver(receiver)
        super.onStop()
    }

    private fun updateStats() {
        val count = getSharedPreferences(AdBlockVpnService.PREFS, MODE_PRIVATE)
            .getLong(AdBlockVpnService.KEY_BLOCKED, 0L)
        stats.text = "Đã chặn: $count kết nối"
    }

    private fun setStatus(on: Boolean) {
        running = on
        status.text = if (on) "● Đang bật" else "● Đang tắt"
        toggle.text = if (on) "TẮT CHẶN QUẢNG CÁO" else "BẬT CHẶN QUẢNG CÁO"
    }

    private fun toggleVpn() {
        if (running) {
            stopService(Intent(this, AdBlockVpnService::class.java))
            setStatus(false)
            return
        }
        val prepare = VpnService.prepare(this)
        if (prepare != null) startActivityForResult(prepare, 100) else startVpn()
    }

    private fun startVpn() {
        startService(Intent(this, AdBlockVpnService::class.java))
        setStatus(true)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) startVpn()
    }
}
